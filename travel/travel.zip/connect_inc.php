<?php

$host="mysql.hostinger.com.ua";
$login="u637457273_user";
$password="kurfurst";
$dbname="u637457273_ww";

?>